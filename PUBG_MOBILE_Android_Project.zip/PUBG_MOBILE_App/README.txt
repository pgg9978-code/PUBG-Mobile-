PUBG MOBILE - Android Studio starter project

This is a first UI prototype based on the screenshots and assets supplied in the conversation.
Open this folder in Android Studio and build the APK (Build > Build Bundle(s) / APK(s) > Build APK(s)).

Included:
- App name: PUBG MOBILE
- Supplied background and four gameplay/menu screenshots
- Supplied M4A audio file with play/pause control
- Pre-registration button saved locally on the current device

Important:
- The pre-registration button is a local prototype only. Central registration across users requires a backend/server.
- Android/browser autoplay policies can require a first user interaction before sound starts. The music button is included.
- Use only music and game artwork you have permission to distribute.
